package redis.clients.jedis.commands;

import redis.clients.jedis.args.Rawable;

public interface ProtocolCommand extends Rawable {
}

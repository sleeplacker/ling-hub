/*
 * This package contains the classes that represent different Redis responses.
 */
package redis.clients.jedis.resps;
